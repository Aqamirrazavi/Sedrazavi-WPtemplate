<?php
/**
 * SedRazavi Case Management & Client Tracker Engine
 *
 * @package SedRazavi
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register Custom Post Type for Legal Cases
 */
if (!function_exists('sedrazavi_register_case_cpt')) {
    function sedrazavi_register_case_cpt() {
        if (class_exists('SedRazavi_Case_Data_Service')) {
            SedRazavi_Case_Data_Service::register_canonical_case_cpt();
        } elseif (!post_type_exists('sedrazavi_case')) {
            $labels = array(
                'name'               => esc_html__('پرونده‌های موکلین', 'sedrazavi'),
                'singular_name'      => esc_html__('پرونده حقوقی', 'sedrazavi'),
                'menu_name'          => esc_html__('مدیریت پرونده‌ها', 'sedrazavi'),
                'add_new'            => esc_html__('ثبت پرونده جدید', 'sedrazavi'),
                'add_new_item'       => esc_html__('ثبت پرونده حقوقی جدید', 'sedrazavi'),
                'edit_item'          => esc_html__('ویرایش پرونده', 'sedrazavi'),
                'all_items'          => esc_html__('همه پرونده‌ها', 'sedrazavi'),
            );

            register_post_type('sedrazavi_case', array(
                'labels'              => $labels,
                'public'              => false,
                'publicly_queryable'  => false,
                'exclude_from_search' => true,
                'show_ui'             => true,
                'show_in_menu'        => true,
                'show_in_nav_menus'   => false,
                'has_archive'         => false,
                'rewrite'             => false,
                'query_var'           => false,
                'menu_icon'           => 'dashicons-portfolio',
                'supports'            => array('title', 'custom-fields', 'revisions', 'author'),
                'show_in_rest'        => false,
                'capability_type'     => array('sedrazavi_case', 'sedrazavi_cases'),
                'map_meta_cap'        => true,
            ));
        }

        // Register Appointments CPT
        if (!post_type_exists('sedrazavi_appointment')) {
            $appointment_labels = array(
                'name'          => esc_html__('نوبت‌های مشاوره', 'sedrazavi'),
                'singular_name' => esc_html__('نوبت مشاوره', 'sedrazavi'),
                'menu_name'     => esc_html__('رزرو نوبت‌ها', 'sedrazavi'),
                'all_items'     => esc_html__('همه نوبت‌ها', 'sedrazavi'),
            );
            register_post_type('sedrazavi_appointment', array(
                'labels'              => $appointment_labels,
                'public'              => false,
                'publicly_queryable'  => false,
                'exclude_from_search' => true,
                'show_ui'             => true,
                'show_in_menu'        => true,
                'show_in_nav_menus'   => false,
                'has_archive'         => false,
                'rewrite'             => false,
                'query_var'           => false,
                'menu_icon'           => 'dashicons-calendar-alt',
                'supports'            => array('title', 'editor', 'custom-fields'),
                'show_in_rest'        => false,
            ));
        }
    }
    add_action('init', 'sedrazavi_register_case_cpt');
}

/**
 * AJAX Handler for Online Case Tracking
 */
if (!function_exists('sedrazavi_ajax_track_case')) {
    function sedrazavi_ajax_track_case() {
        check_ajax_referer('sedrazavi_security_nonce', 'security');

        // Rate limiting: max 12 tracking queries per 5 minutes per IP
        if (class_exists('SedRazavi_Rate_Limiter') && !SedRazavi_Rate_Limiter::check_rate_limit('tracking', 12, 300)) {
            wp_send_json_error(array(
                'rate_limited' => true,
                'message'      => esc_html__('تعداد استعلام‌های پی‌درپی بیش از حد مجاز است. لطفاً پس از چند دقیقه مجدداً تلاش نمایید.', 'sedrazavi')
            ), 429);
        }

        $case_number  = isset($_POST['case_number']) ? sanitize_text_field(wp_unslash($_POST['case_number'])) : '';
        $client_phone = isset($_POST['client_phone']) ? sanitize_text_field(wp_unslash($_POST['client_phone'])) : '';

        if (empty($case_number) || empty($client_phone)) {
            wp_send_json_error(array('message' => esc_html__('لطفاً شماره پرونده و شماره تلفن ثبت‌شده موکل را وارد فرمایید.', 'sedrazavi')), 400);
        }

        $norm_phone = function($num) {
            $num = str_replace(array('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'), array('0','1','2','3','4','5','6','7','8','9'), $num);
            return ltrim(preg_replace('/[^\d]/', '', $num), '0');
        };
        $clean_phone = $norm_phone($client_phone);

        $case_post_types = class_exists('SedRazavi_Case_Data_Service')
            ? SedRazavi_Case_Data_Service::get_litigation_post_types()
            : array('sedrazavi_case', 'case');

        $query = new WP_Query(array(
            'post_type'      => $case_post_types,
            'post_status'    => array('private', 'publish'),
            'meta_query'     => array(
                'relation' => 'OR',
                array(
                    'key'     => '_sedrazavi_case_number',
                    'value'   => $case_number,
                    'compare' => '=',
                ),
                array(
                    'key'     => '_case_number',
                    'value'   => $case_number,
                    'compare' => '=',
                ),
            ),
            'posts_per_page' => 1,
        ));

        if ($query->have_posts()) {
            $query->the_post();
            $post_id = get_the_ID();
            $stored_phone = get_post_meta($post_id, '_sedrazavi_client_phone', true);
            $clean_stored = $norm_phone($stored_phone);

            if (empty($clean_stored) || !hash_equals($clean_stored, $clean_phone)) {
                wp_reset_postdata();
                wp_send_json_error(array('message' => esc_html__('پرونده‌ای با این شماره و تلفن همراه یافت نشد.', 'sedrazavi')), 404);
            }

            $response = array(
                'found'            => true,
                'case_number'      => $case_number,
                'case_type'        => get_post_meta($post_id, '_sedrazavi_case_type', true) ?: 'حقوقی',
                'status'           => get_post_meta($post_id, '_sedrazavi_case_status', true) ?: 'در جریان',
                'next_session'     => get_post_meta($post_id, '_sedrazavi_next_session', true) ?: 'تعیین نشده',
                'documents_count'  => (int) (get_post_meta($post_id, '_sedrazavi_docs_count', true) ?: 0),
            );
            wp_reset_postdata();
            wp_send_json_success($response);
        } else {
            wp_send_json_error(array('message' => esc_html__('پرونده‌ای با این مشخصات یافت نشد.', 'sedrazavi')), 404);
        }
    }
    add_action('wp_ajax_sedrazavi_track_case', 'sedrazavi_ajax_track_case');
    add_action('wp_ajax_nopriv_sedrazavi_track_case', 'sedrazavi_ajax_track_case');
}
